#include <math.h>

const byte buzzerPins[4] = { 8, 7, 4, 2 };


const byte trigPin = 3;
const byte echoPin = 13;

// Joystick
const byte joyXPin = A0;
const byte joyYPin = A1;
const byte joySWPin = 5;

// Rotary encoder
const byte encoderCLK = 9;
const byte encoderDT = 10;
const byte encoderSW = 11;


const int NUM_SCALES = 8;

const int scales[NUM_SCALES][7] = {

  // C Major
  // C D E F G A B
  { 0, 2, 4, 5, 7, 9, 11 },

  // D Major
  // D E F# G A B C#
  { 2, 4, 6, 7, 9, 11, 13 },

  // E Natural Minor
  // E F# G A B C D
  { 4, 6, 7, 9, 11, 12, 14 },

  // F Major
  // F G A Bb C D E
  { 5, 7, 9, 10, 12, 14, 16 },

  // G Major
  // G A B C D E F#
  { 7, 9, 11, 12, 14, 16, 18 },

  // A Harmonic Minor
  // A B C D E F G#
  { 9, 11, 12, 14, 16, 17, 20 },

  // B Natural Minor
  // B C# D E F# G A
  { 11, 13, 14, 16, 18, 19, 21 },

  // E Phrygian Dominant
  // E F G# A B C D
  { 4, 5, 8, 9, 11, 12, 14 }

};


const char* scaleNames[NUM_SCALES] = {

  "C Major",
  "D Major",
  "E Minor",
  "F Major",
  "G Major",
  "A Harmonic Minor",
  "B Minor",
  "E Phrygian Dominant"

};


int currentScale = 0;

const int JOY_LOW = 300;
const int JOY_HIGH = 700;

int currentDirection = -1;


float chordNotes[4];



const int NUM_PATTERNS = 7;


// Pattern 0
const byte patternUp[] = {
  0, 1, 0, 2, 3
};

// Pattern 1
const byte patternDown[] = {
  3, 2, 1, 0
};

// Pattern 2
const byte patternUpDown[] = {
  0, 1, 2, 3, 2, 1
};

// Pattern 3
const byte patternOutsideIn[] = {
  0, 3, 1, 2
};

// Pattern 4
const byte patternInsideOut[] = {
  1, 2, 0, 3
};

// Pattern 5
const byte patternSkip[] = {
  0, 2, 1, 3
};

// Pattern 6 = random
// handled separately


const char* patternNames[NUM_PATTERNS] = {

  "UP",
  "DOWN",
  "UP-DOWN",
  "OUTSIDE-IN",
  "INSIDE-OUT",
  "SKIP",
  "RANDOM"
};


int currentPattern = 0;

int patternStep = 0;




unsigned long lastArpChange = 0;

unsigned long arpInterval = 300;


const float MIN_DISTANCE = 4.0;
const float MAX_DISTANCE = 35.0;

// close = FAST
const unsigned long FASTEST_ARP = 45;

// far = SLOW
const unsigned long SLOWEST_ARP = 900;

float filteredDistance = 20.0;

unsigned long lastDistanceCheck = 0;



float getScaleFrequency(
  int scaleNumber,
  int absoluteDegree) {

  int octave =
    absoluteDegree / 7;

  int degree =
    absoluteDegree % 7;


  int semitone =
    scales[scaleNumber][degree]
    + octave * 12;


  return 261.63 * pow(2.0, semitone / 12.0);
}




void buildChord(int direction) {

  if (direction < 0) {
    return;
  }



  if (direction <= 6) {

    int root = direction;


    chordNotes[0] =
      getScaleFrequency(
        currentScale,
        root);


    chordNotes[1] =
      getScaleFrequency(
        currentScale,
        root + 2);


    chordNotes[2] =
      getScaleFrequency(
        currentScale,
        root + 4);


    chordNotes[3] =
      getScaleFrequency(
        currentScale,
        root + 6);
  }


  // Direction 7:
  // tonic add9

  else {

    chordNotes[0] =
      getScaleFrequency(
        currentScale,
        0);


    chordNotes[1] =
      getScaleFrequency(
        currentScale,
        2);


    chordNotes[2] =
      getScaleFrequency(
        currentScale,
        4);


    chordNotes[3] =
      getScaleFrequency(
        currentScale,
        8);
  }


  patternStep = 0;

  lastArpChange = 0;
}


int readJoystickDirection() {

  int x = analogRead(joyXPin);
  int y = analogRead(joyYPin);


  bool left = x < JOY_LOW;
  bool right = x > JOY_HIGH;

  bool up = y < JOY_LOW;
  bool down = y > JOY_HIGH;


  // UP
  if (
    up && !left && !right) {
    return 0;
  }


  // UP RIGHT
  if (
    up && right) {
    return 1;
  }


  // RIGHT
  if (
    right && !up && !down) {
    return 2;
  }


  // DOWN RIGHT
  if (
    down && right) {
    return 3;
  }


  // DOWN
  if (
    down && !left && !right) {
    return 4;
  }


  // DOWN LEFT
  if (
    down && left) {
    return 5;
  }


  // LEFT
  if (
    left && !up && !down) {
    return 6;
  }


  // UP LEFT
  if (
    up && left) {
    return 7;
  }


  // CENTER
  return -1;
}



void stopBuzzers() {

  for (int i = 0; i < 4; i++) {

    noTone(
      buzzerPins[i]);
  }
}



int getPatternNote() {

  int noteIndex = 0;


  // UP
  if (currentPattern == 0) {

    noteIndex =
      patternUp[patternStep];

    patternStep++;

    if (patternStep >= 4) {
      patternStep = 0;
    }
  }


  // DOWN
  else if (currentPattern == 1) {

    noteIndex =
      patternDown[patternStep];

    patternStep++;

    if (patternStep >= 4) {
      patternStep = 0;
    }
  }


  // UP-DOWN
  else if (currentPattern == 2) {

    noteIndex =
      patternUpDown[patternStep];

    patternStep++;

    if (patternStep >= 6) {
      patternStep = 0;
    }
  }


  // OUTSIDE-IN
  else if (currentPattern == 3) {

    noteIndex =
      patternOutsideIn[patternStep];

    patternStep++;

    if (patternStep >= 4) {
      patternStep = 0;
    }
  }


  // INSIDE-OUT
  else if (currentPattern == 4) {

    noteIndex =
      patternInsideOut[patternStep];

    patternStep++;

    if (patternStep >= 4) {
      patternStep = 0;
    }
  }


  // SKIP
  else if (currentPattern == 5) {

    noteIndex =
      patternSkip[patternStep];

    patternStep++;

    if (patternStep >= 4) {
      patternStep = 0;
    }
  }


  // RANDOM
  else {

    noteIndex =
      random(0, 4);
  }


  return noteIndex;
}



void updateArpeggiator() {

  if (currentDirection < 0) {

    stopBuzzers();

    return;
  }


  unsigned long now =
    millis();


  if (
    now - lastArpChange >= arpInterval) {

    lastArpChange = now;


    stopBuzzers();


    int noteIndex =
      getPatternNote();


    // 75% note, 25% gap
    unsigned long noteDuration =
      arpInterval * 0.75;


    // Each chord note also gets
    // its own physical buzzer

    tone(
      buzzerPins[noteIndex],

      (unsigned int)
        chordNotes[noteIndex],

      noteDuration);
  }
}



void updateUltrasonic() {

  if (
    millis() - lastDistanceCheck < 35) {

    return;
  }


  lastDistanceCheck =
    millis();


  // Trigger pulse

  digitalWrite(
    trigPin,
    LOW);

  delayMicroseconds(2);


  digitalWrite(
    trigPin,
    HIGH);

  delayMicroseconds(10);


  digitalWrite(
    trigPin,
    LOW);


  unsigned long duration =
    pulseIn(
      echoPin,
      HIGH,
      5000);


  // No valid echo
  if (duration == 0) {
    return;
  }


  float distance =
    duration / 58.0;


  // Ignore nonsense
  if (
    distance < 2 || distance > 50) {

    return;
  }


  // Responsive smoothing
  filteredDistance =
    filteredDistance * 0.30
    + distance * 0.70;


  float d =
    constrain(
      filteredDistance,
      MIN_DISTANCE,
      MAX_DISTANCE);


  // Convert to 0-1
  float normalized =
    (d - MIN_DISTANCE)
    / (MAX_DISTANCE - MIN_DISTANCE);


  normalized =
    constrain(
      normalized,
      0.0,
      1.0);


  // Nonlinear response
  normalized =
    normalized * normalized;


  arpInterval =
    FASTEST_ARP
    + normalized * (SLOWEST_ARP - FASTEST_ARP);
}



bool previousJoyButton = HIGH;

unsigned long lastJoyButtonPress = 0;


void updateScaleButton() {

  bool button =
    digitalRead(
      joySWPin);


  if (
    previousJoyButton == HIGH && button == LOW) {

    if (
      millis() - lastJoyButtonPress > 250) {

      lastJoyButtonPress =
        millis();


      currentScale++;


      if (
        currentScale >= NUM_SCALES) {

        currentScale = 0;
      }


      if (
        currentDirection >= 0) {

        buildChord(
          currentDirection);
      }


      Serial.print(
        "SCALE -> ");

      Serial.println(
        scaleNames[currentScale]);
    }
  }


  previousJoyButton =
    button;
}




int lastEncoderCLK = HIGH;

unsigned long lastEncoderTurn = 0;


void updateEncoder() {

  int clkState =
    digitalRead(
      encoderCLK);


  // Detect change
  if (
    clkState != lastEncoderCLK) {

    // Only count falling edge
    if (
      clkState == LOW && millis() - lastEncoderTurn > 3) {

      lastEncoderTurn =
        millis();


      int dtState =
        digitalRead(
          encoderDT);


      // One direction
      if (
        dtState != clkState) {

        currentPattern++;

        if (
          currentPattern >= NUM_PATTERNS) {

          currentPattern = 0;
        }
      }


      // Other direction
      else {

        currentPattern--;

        if (
          currentPattern < 0) {

          currentPattern =
            NUM_PATTERNS - 1;
        }
      }


      // Restart pattern cleanly
      patternStep = 0;


      Serial.print(
        "PATTERN -> ");

      Serial.println(
        patternNames[currentPattern]);
    }
  }


  lastEncoderCLK =
    clkState;
}


bool previousEncoderButton = HIGH;

unsigned long lastEncoderButtonPress = 0;


void updateEncoderButton() {

  bool button =
    digitalRead(
      encoderSW);


  if (
    previousEncoderButton == HIGH && button == LOW) {

    if (
      millis() - lastEncoderButtonPress > 250) {

      lastEncoderButtonPress =
        millis();


      // Reset to normal UP pattern
      currentPattern = 0;

      patternStep = 0;


      Serial.println(
        "PATTERN RESET -> UP");
    }
  }


  previousEncoderButton =
    button;
}


// ======================================================
// SETUP
// ======================================================

void setup() {

  Serial.begin(115200);


  // Buzzers
  for (int i = 0; i < 4; i++) {

    pinMode(
      buzzerPins[i],
      OUTPUT);
  }


  // Ultrasonic
  pinMode(
    trigPin,
    OUTPUT);

  pinMode(
    echoPin,
    INPUT);


  // Joystick
  pinMode(
    joySWPin,
    INPUT_PULLUP);


  // Rotary encoder
  pinMode(
    encoderCLK,
    INPUT_PULLUP);

  pinMode(
    encoderDT,
    INPUT_PULLUP);

  pinMode(
    encoderSW,
    INPUT_PULLUP);


  digitalWrite(
    trigPin,
    LOW);


  lastEncoderCLK =
    digitalRead(
      encoderCLK);


  // Random pattern seed
  randomSeed(
    analogRead(A2));


  Serial.println(
    "ARPEGGIATOR READY");


  Serial.print(
    "Scale: ");

  Serial.println(
    scaleNames[currentScale]);


  Serial.print(
    "Pattern: ");

  Serial.println(
    patternNames[currentPattern]);
}


// ======================================================
// MAIN LOOP
// ======================================================

void loop() {

  // ------------------------------
  // SCALE BUTTON
  // ------------------------------

  updateScaleButton();


  // ------------------------------
  // ROTARY ENCODER
  // ------------------------------

  updateEncoder();

  updateEncoderButton();


  // ------------------------------
  // JOYSTICK CHORD
  // ------------------------------

  int direction =
    readJoystickDirection();


  if (
    direction != currentDirection) {

    currentDirection =
      direction;


    stopBuzzers();


    if (
      direction >= 0) {

      buildChord(
        direction);
    }
  }


  // ------------------------------
  // ULTRASONIC TEMPO
  // ------------------------------

  updateUltrasonic();


  // ------------------------------
  // PLAY
  // ------------------------------

  updateArpeggiator();


  // ------------------------------
  // SERIAL DEBUG
  // ------------------------------

  static unsigned long lastPrint = 0;


  if (
    millis() - lastPrint > 300) {

    lastPrint =
      millis();


    Serial.print(
      scaleNames[currentScale]);


    Serial.print(
      " | Pattern: ");

    Serial.print(
      patternNames[currentPattern]);


    Serial.print(
      " | Distance: ");

    Serial.print(
      filteredDistance,
      1);


    Serial.print(
      " cm | Speed: ");

    Serial.print(
      arpInterval);


    Serial.println(
      " ms");
  }
}