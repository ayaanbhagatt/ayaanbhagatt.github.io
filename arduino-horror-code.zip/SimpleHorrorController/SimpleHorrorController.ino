// Joystick: VRx A0, VRy A1, SW 7.
// HC-SR04: TRIG 3, ECHO 2. Both modules: 5V and common GND.
// For Arduino Uno / classic Nano (5V). Close Serial Monitor before playing.

void setup() {
  pinMode(7, INPUT_PULLUP);
  pinMode(3, OUTPUT);
  pinMode(2, INPUT);
  Serial.begin(115200);
}

void loop() {
  digitalWrite(3, LOW);
  delayMicroseconds(2);
  digitalWrite(3, HIGH);
  delayMicroseconds(10);
  digitalWrite(3, LOW);

  unsigned long echoTime = pulseIn(2, HIGH, 25000);
  float distance = echoTime ? echoTime / 58.3 : -1;

  // Same message format as the previous Arduino sketch.
  Serial.print("SH1,");
  Serial.print(millis());
  Serial.print(',');
  Serial.print(analogRead(A0));
  Serial.print(',');
  Serial.print(analogRead(A1));
  Serial.print(',');
  Serial.print(digitalRead(7) == LOW ? 1 : 0);
  Serial.print(',');
  Serial.println(distance, 1);
  delay(60);
}
