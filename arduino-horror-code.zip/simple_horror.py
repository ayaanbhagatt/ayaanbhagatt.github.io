"""One-file 2D Arduino horror game. Install: pip install pygame pyserial
VRx=A0, VRy=A1, SW=7, ultrasonic TRIG=3 / ECHO=2. No calibration.
Your existing SH1 Arduino sketch works with this game.
"""
import math
import random
import time
from array import array

import pygame
import serial
from serial.tools import list_ports

# SETTINGS: these are the main values you might want to change.
PORT = ""                 # e.g. "COM3" or "/dev/cu.usbmodem1101"; blank = automatic
NEAR_CM = 30             # Closer = forward. Between NEAR and FAR = stop.
FAR_CM = 40              # Farther = backward. Joystick only moves sideways.
INVERT_X = False          # Change to True if the joystick moves the wrong way.
PLAYER_SPEED = 150
SEEN_TIME = .65           # Seconds exposed before being caught.

pygame.mixer.pre_init(22050, -16, 1)
pygame.init()
screen = pygame.display.set_mode((900, 650))
pygame.display.set_caption("DON'T LET IT SEE YOU")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 25)
big_font = pygame.font.Font(None, 48)
white, red, green, yellow = (220, 224, 215), (230, 80, 80), (105, 205, 155), (235, 194, 90)
floor = pygame.Rect(35, 105, 830, 465)
door = pygame.Rect(410, 105, 80, 24)
monster = (450, 165)

# Three unlabeled levels. Obstacles shift each time a level starts.
rooms = [
    {"colour": (24, 34, 32), "item_pos": (450, 270),
     "cover": [(280, 355, 100, 55), (520, 355, 100, 55)]},
    {"colour": (37, 29, 27), "item_pos": (680, 260),
     "cover": [(230, 290, 100, 65), (550, 385, 100, 65), (420, 260, 60, 45)]},
    {"colour": (26, 29, 40), "item_pos": (260, 245),
     "cover": [(190, 350, 110, 60), (550, 285, 110, 60), (390, 430, 80, 50)]},
]


def text(message, y, colour=white, large=False):
    image = (big_font if large else font).render(message, True, colour)
    screen.blit(image, (450 - image.get_width() // 2, y))


def sound(scary=False):
    """Generate two small sounds so there are no sound files to download."""
    if not pygame.mixer.get_init():
        return None
    samples = array("h")
    for i in range(7700):
        t = i / 22050
        tone = math.sin(2 * math.pi * (650 if scary else 55) * t)
        value = (tone + random.uniform(-.5, .5) if scary else tone) * math.exp(-t * 14)
        samples.append(int(value * (9500 if scary else 5000)))
    return pygame.mixer.Sound(buffer=samples.tobytes())


heartbeat, scream = sound(), sound(True)

# Connect once. Reading uses timeout=0 so the game never waits for USB data.
connection = None
try:
    ports = list(list_ports.comports())
    usb_ports = [p for p in ports if p.vid is not None]
    choices = usb_ports or ports
    if not PORT and len(choices) == 1:
        PORT = choices[0].device
    if PORT:
        connection = serial.Serial(PORT, 115200, timeout=0)
except (serial.SerialException, OSError) as error:
    print(error)

keyboard = connection is None
serial_buffer = b""
joy_x, button, distance = 512, False, None
last_packet = 0
previous_button = False


def new_room(index):
    """Reset positions and timers when entering a room."""
    covers = [pygame.Rect(x + random.randint(-35, 35), y + random.randint(-18, 18), w, h)
              for x, y, w, h in rooms[index]["cover"]]
    return [450.0, 530.0], False, "away", random.uniform(4, 7), 0.0, covers


room_number = 0
player, has_item, phase, timer, seen, covers = new_room(0)
state = "title"            # title, playing, caught, or won
scare_time = 0
beat_timer = 0
running = True

try:
    while running:
        dt = min(clock.tick(60) / 1000, .05)
        now = time.monotonic()
        use = start = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_r):
                    start = True
                if event.key == pygame.K_e:
                    use = True
                if event.key == pygame.K_k:
                    keyboard = True

        # Expected line: SH1,milliseconds,x,y,button,distance_cm
        if connection and not keyboard:
            try:
                serial_buffer += connection.read(min(connection.in_waiting, 2048))
                while b"\n" in serial_buffer:
                    line, serial_buffer = serial_buffer.split(b"\n", 1)
                    try:
                        data = line.decode("ascii").strip().split(",")
                        if len(data) != 6 or data[0] != "SH1":
                            continue
                        x, y, pressed = int(data[2]), int(data[3]), int(data[4])
                        cm = float(data[5])
                        if not (0 <= x <= 1023 and 0 <= y <= 1023 and pressed in (0, 1)):
                            continue
                        joy_x, button = x, bool(pressed)
                        distance = cm if math.isfinite(cm) and 2 <= cm <= 400 else None
                        last_packet = now
                        if button and not previous_button:
                            use = start = True
                        previous_button = button
                    except (ValueError, UnicodeError):
                        pass
                if len(serial_buffer) > 2048:
                    serial_buffer = b""
            except (serial.SerialException, OSError):
                last_packet = 0

        keys = pygame.key.get_pressed()
        if keyboard:
            dx = int(keys[pygame.K_d] or keys[pygame.K_RIGHT]) - int(keys[pygame.K_a] or keys[pygame.K_LEFT])
            dy = int(keys[pygame.K_s] or keys[pygame.K_DOWN]) - int(keys[pygame.K_w] or keys[pygame.K_UP])
            controller_ok = True
        else:
            dx = (joy_x - 512) / 512
            if abs(dx) < .18:
                dx = 0
            dx = -dx if INVERT_X else dx
            dy = -1 if distance is not None and distance < NEAR_CM else 0
            if distance is not None and distance > FAR_CM:
                dy = 1
            # A missing echo stops forward/back movement, not the joystick.
            controller_ok = now - last_packet < .5
        if state != "playing" and start and scare_time <= 0:
            room_number = 0
            player, has_item, phase, timer, seen, covers = new_room(0)
            state = "playing"
            use = False

        room = rooms[room_number]
        hidden = any(cover.clipline(monster, player) for cover in covers)

        if state == "playing" and controller_ok:
            # Move on one axis at a time; boxes block the player.
            for axis, movement in ((0, dx), (1, dy)):
                old_position = player[axis]
                player[axis] += movement * PLAYER_SPEED * dt
                body = pygame.Rect(player[0] - 10, player[1] - 10, 20, 20)
                if not floor.contains(body) or any(body.colliderect(c) for c in covers):
                    player[axis] = old_position
            hidden = any(cover.clipline(monster, player) for cover in covers)

            # Random pauses, short looks, long looks, and occasional fake turns.
            timer -= dt
            if timer <= 0:
                if phase == "away":
                    phase, timer = "turning", random.uniform(1.8, 3.0)
                elif phase == "turning":
                    phase = "away" if random.random() < .2 else "watching"
                    timer = random.uniform(.8, 3.8)
                else:
                    phase, timer = "away", random.uniform(2.2, 7.5)
            if phase == "watching" and not hidden:
                seen += dt
            else:
                seen = max(0, seen - dt * 2)
            if seen >= SEEN_TIME:
                state, scare_time = "caught", .6
                if scream:
                    scream.play()

            if use and state == "playing":
                if not has_item and math.dist(player, room["item_pos"]) < 38:
                    has_item = True
                elif has_item and math.dist(player, door.center) < 60:
                    if room_number == len(rooms) - 1:
                        state = "won"
                    else:
                        room_number += 1
                        player, has_item, phase, timer, seen, covers = new_room(room_number)
                        continue

        # Everything below this line just draws the 2D game.
        screen.fill((10, 12, 16))
        pygame.draw.rect(screen, room["colour"], floor)
        pygame.draw.rect(screen, (75, 79, 76), floor, 3)
        for y in range(145, 570, 45):
            pygame.draw.line(screen, (43, 44, 46), (38, y), (862, y))
        pygame.draw.rect(screen, green if has_item else (100, 90, 55), door)

        for cover in covers:
            pygame.draw.rect(screen, (71, 78, 74), cover)
            pygame.draw.rect(screen, (116, 127, 116), cover, 2)
        if not has_item:
            ix, iy = room["item_pos"]
            pygame.draw.circle(screen, yellow, (ix, iy), 9)

        # Pale creature, red eyes when facing you; blue player.
        pygame.draw.rect(screen, (150, 153, 137), (436, 177, 28, 32))
        pygame.draw.circle(screen, (190, 194, 175), monster, 20)
        if phase != "away":
            for eye_x in (442, 458):
                pygame.draw.circle(screen, yellow if phase == "turning" else red, (eye_x, 167), 4)
            pygame.draw.line(screen, (20, 15, 17), (443, 178), (457, 178), 3)
        else:
            pygame.draw.line(screen, (28, 30, 27), (450, 145), (450, 166), 6)
        pygame.draw.circle(screen, (100, 170, 225), (int(player[0]), int(player[1])), 11)
        pygame.draw.rect(screen, (42, 24, 27), (345, 55, 210, 8))
        pygame.draw.rect(screen, red, (345, 55, int(210 * min(1, seen / SEEN_TIME)), 8))

        if state == "title":
            screen.fill((10, 12, 16))
            text("DON'T LET IT SEE YOU", 260, white, True)
            text("PRESS ENTER" if keyboard else "CLICK JOYSTICK", 340, green)
        elif state == "playing" and not controller_ok:
            text("Controller disconnected. K for keyboard.", 600, yellow)
        elif state in ("caught", "won"):
            scare_time = max(0, scare_time - dt)
            screen.fill((10, 12, 16))
            text("IT SAW YOU." if state == "caught" else "YOU ESCAPED.", 270, red if state == "caught" else green, True)
            text("PRESS ENTER" if keyboard else "CLICK JOYSTICK", 350)
            if scare_time > 0:
                screen.fill((32, 5, 8))
                pygame.draw.circle(screen, (185, 185, 161), (450, 320), 185)
                pygame.draw.ellipse(screen, (7, 5, 8), (340, 240, 65, 50))
                pygame.draw.ellipse(screen, (7, 5, 8), (495, 240, 65, 50))
                pygame.draw.ellipse(screen, (10, 5, 8), (410, 340, 80, 130))
        beat_timer -= dt
        if state == "playing" and controller_ok and phase != "away" and beat_timer <= 0:
            if heartbeat:
                heartbeat.play()
            beat_timer = .65
        pygame.display.flip()
finally:
    if connection:
        connection.close()
    pygame.quit()
