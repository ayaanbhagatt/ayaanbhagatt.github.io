Install Python, then run:
python -m pip install pygame pyserial
python simple_horror.py

Upload SimpleHorrorController/SimpleHorrorController.ino to an Uno or classic Nano.
Close Serial Monitor before starting the game. Set PORT at the top of simple_horror.py if automatic detection does not find the Arduino.

Joystick VRx=A0, VRy=A1, SW=7. HC-SR04 TRIG=3, ECHO=2; modules share 5V and GND.

Click joystick to start and interact. VRx steers sideways. Distance controls forward/backward movement; NEAR_CM and FAR_CM are adjustable at the top of the script.
